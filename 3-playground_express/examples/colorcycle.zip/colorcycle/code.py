import time
from adafruit_circuitplayground.express import cpx
import random

RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

cpx.pixels.brightness = 0.1

while True:
    if cpx.button_a:
        RCOLOR = RED
    else:
        RCOLOR = (random.randrange(255), random.randrange(255), random.randrange(255))
    cpx.pixels.fill(RCOLOR)
    time.sleep(random.random() / 2)