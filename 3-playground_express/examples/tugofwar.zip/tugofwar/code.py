# Circuit Playground Express Tug-of-War
                
import time
import board
import digitalio
import neopixel
import random

global buttonApushed, buttonBpushed, status

# set up D13 (red LED) for output
led = digitalio.DigitalInOut(board.D13)
led.switch_to_output()
# set up slide switch (for turning game on and off)
switch = digitalio.DigitalInOut(board.SLIDE_SWITCH)
switch.direction = digitalio.Direction.INPUT
switch.pull = digitalio.Pull.UP

# set up button A to accept presses
buttonA = digitalio.DigitalInOut(board.BUTTON_A)
buttonA.switch_to_input(pull=digitalio.Pull.DOWN)

# set up button B to accept presses
buttonB = digitalio.DigitalInOut(board.BUTTON_B)
buttonB.switch_to_input(pull=digitalio.Pull.DOWN)

# set up neopixels
pixels = neopixel.NeoPixel(board.NEOPIXEL, 10, brightness=0.2, auto_write=False)

# establish colors
RED = (255, 0, 0)
YELLOW = (255, 150, 0)
GREEN = (0, 255, 0)
CYAN = (0, 255, 255)
BLUE = (0, 0, 255)
PURPLE = (180, 0, 255)
WHITE = (255, 255, 255)
OFF = (0, 0, 0)

# Two contestants, A and B. Who ever gets the color all the way to their
# side wins the Tug-of-War
status = -1  # start
gameOver = False
delay = random.randint(1, 7)  # Set a random delay until players can push button
start = time.monotonic()  # Record the start time (milliseconds)
buttonApushed = False  # Clear both button values
buttonBpushed = False

while not gameOver:  # Run loop infinitely to monitor inputs
    if buttonA.value:
        buttonApushed = True
    if buttonB.value:
        buttonBpushed = True
    if time.monotonic() - start > delay:  # if time has elapsed:
        led.value = True  # ... turn on red LED...
        if buttonApushed:  # ... and check for button pushes
            if status == -1:
                status = 4
            else:
                status -= 1
        if buttonBpushed:
            if status == -1:
                status = 5
            else:
                status += 1
    else:
        if buttonApushed:  # if they pushed before time, they
            if status == -1:  # get penalized
                status = 5
            else:
                status += 1
        if buttonBpushed:
            if status == -1:
                status = 4
            else:
                status -= 1
    # Update NeoPixel status
    if buttonApushed or buttonBpushed:
        led.value = False
        if status < 0:      # Button A/RED won!
            color = RED
            pixels.fill(color)
            pixels.show()
            time.sleep(3)
            gameOver = True
        elif status > 9:      # Button B/BLUE won!
            color = BLUE
            pixels.fill(color)
            pixels.show()
            time.sleep(3)
            gameOver = True
        elif status < 5:    # Red is winning
            color = RED
        else:
            color = BLUE    # Blue is winning
        for i in range(10): # show 1 pixel
            if i != status:
                pixels[i] = OFF
            else:
                pixels[i] = color
        pixels.show()
        buttonApushed = False   # reset buttons
        buttonBpushed = False
        time.sleep(1)           # wait a second
        delay = random.randint(1, 7)    # reset time...
        start = time.monotonic()