from adafruit_circuitplayground.express import cpx
import time
import random

def flash():
    for i in range(3):
        # cpx.pixels.brightness(0.7)
        cpx.pixels[0:9] = [(255, 255, 255)] * 9
        time.sleep(random.random() / 10)
        cpx.pixels[0:9] = [(0, 0, 0)] * 9
        time.sleep(random.random() / 10)


x, y, z = cpx.acceleration

while True:
    if cpx.switch:
        oldx, oldy, oldz = x, y, z
        time.sleep(0.1)
        x, y, z = cpx.acceleration
        diff = ((x-oldx)**2 + (y-oldy)**2 + (z-oldz)**2)**0.5
        print(diff)
        if random.random() < 0.05:
            flash()

        if diff > 0.9:
            cpx.play_file("witch.wav")
            x, y, z = cpx.acceleration
